nums = [2,5,5,11]
target = 10
for index,item in enumerate(nums):
    print(index,item)
    if target-item in nums:
        
        a = index
        b = nums.index(sub)
    