class Solution(object):
    def getSum(self, a, b):
        """
        :type a: int
        :type b: int
        :rtype: int
        """
        return sum([a,b])

if __name__ == '__main__':
    solu = Solution()
    print(solu.getSum(1,2))