class Solution:
    def checkRecord(self, n):
        """
        :type n: int
        :rtype: int
        """
