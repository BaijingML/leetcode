# leetcode
It is my solutions of leetcode questions with python.
