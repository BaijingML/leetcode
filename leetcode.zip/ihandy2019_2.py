#!/usr/bin/env python
# encoding: utf-8

"""
@version: python3.6
@Author  : Zhangfusheng
@Time    : 2019/7/30 22:20
@File    : ihandy2019_2
@Software: PyCharm
"""

if __name__ == "__main__":
    string = input().split(' ')
    print(len(string[-1]))